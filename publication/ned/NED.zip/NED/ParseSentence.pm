package ParseSentence;

use POS;
use strict;

sub new {
	my ($class, $poses, $model, $punctRE) = @_;

	my $self = {};

	if (defined $model) {
		my @posRefs = ();

		for (my $i = 0 ; $i < @{$poses} ; ++$i) {
			unless (defined ($poses->[$i])) {
				push(@posRefs, new POS(undef, $i+1, undef, undef));
			} elsif (POS::isPunct($poses->[$i], $punctRE)) {
				push(@posRefs, undef);
			} else {
				push(@posRefs, new POS($poses->[$i], $i+1, $model->{CONTEND}->{$poses->[$i]}, $model->{DEP}->{$poses->[$i]}));

			}
		}
		#map {new POS($_, $model->{CONTEND}->{$_}, $model->{DEP}->{$_}) } @{$poses};

		$self->{POSES} = \@posRefs;
		$self->{MODEL} = $model;
		$self->{DATA} = $poses;
		$self->{ROOT} = undef;
	} else {
		# copy ctor.
		my @posRefs =  map {new POS($_) } @{$poses->{POSES}};
		$self->{POSES} = \@posRefs;
		$self->{MODEL} = $poses->{MODEL};
		$self->{DATA} = $poses->{DATA};
		$self->{ROOT} = $poses->root();
	}

	bless($self, $class);

	return $self;
}

sub clone($) {
	my $self = shift;

	my $sent = new ParseSentence($self);

	return $sent;
}

sub addPosParent($$$) {
	my $self = shift;
	my $pos = shift;
	my $val = shift;

	my $posIndex = $pos-1;
	my $valIndex = $val-1;

	return if (not defined $self->{POSES}->[$posIndex]);

	$self->{POSES}->[$posIndex]->setParent($val);

	if ($pos < $val) {
		$self->{POSES}->[$valIndex]->addLeft($self->{POSES}->[$posIndex]);
	} elsif ($val != POS::ROOT) {
		$self->{POSES}->[$valIndex]->addRight($self->{POSES}->[$posIndex]);
	} else {
		if (defined $self->{ROOT}) {
			return undef;
		}
		$self->root($pos);
	}
}


sub posByIndex($$) {
	my $self = shift;
	my $index = shift;

	return $self->{POSES}->[$index - 1];
}

sub root($) {
	my $self = shift;

	my $root = shift;

	if (defined $root) {
		$self->{ROOT} = $self->{POSES}->[$root-1]->data();
	} elsif (not defined ($self->{ROOT})) {
		return undef;
	} else {
		return $self->{ROOT};
	}
}

sub toString($) {
	my $self = shift;

	my $s;

	foreach my $pos (@{$self->{POSES}}) {
		next unless defined $pos;
		$s .= $pos->toString().",";
	}

	chop($s);

	return $s;
}

sub parserOutput($) {
	my $self = shift;

	my $firstPart ="[".join(",", @{$self->{DATA}})."] ";
	my $secondPart = "[".join(",", map {$_->parent()} @{$self->{POSES}})."]";

	return  $firstPart.$secondPart;
}




1;